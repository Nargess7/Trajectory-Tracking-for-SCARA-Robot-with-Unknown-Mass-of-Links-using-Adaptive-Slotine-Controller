clc
clear all
close all
%% Q2
plot3(xdes.Data(:,1),xdes.Data(:,2),xdes.Data(:,3),'b--','linewidth',2)
hold on
grid on
plot3(x.Data(:,1),x.Data(:,2),x.Data(:,3),'r','linewidth',2)
hold on
title('Tracking Performance')
%% Q4
plot3(xdes.Data(:,1),xdes.Data(:,2),xdes.Data(:,3),'b--','linewidth',2)
hold on
grid on
plot3(x.Data(:,1),x.Data(:,2),x.Data(:,3),'r','linewidth',2)
hold on
title('Tracking Performance')