clc
clear all
close all
%% Q3
syms t1 t2 dt1 dt2 L1 L2
 O=[(L2*cos(t1 + t2))/2 + L1*cos(t1);(L2*sin(t1 + t2))/2 + L1*sin(t1);0]
 A=[0.25;-0.4;0]
 f1=(O-A)
 F=f1.'*f1
 %%
 gradf=[diff(F,t1)*dt1;diff(F,t2)*dt2;0;0]
 gradf=simplify(gradf)
 %%
 
                                